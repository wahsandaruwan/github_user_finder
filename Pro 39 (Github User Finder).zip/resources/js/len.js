// For get lentgths of each path of the SVG logo

// const logo = document.querySelectorAll(".logo svg path");

// for(let i = 0; i < logo.length; i++){
//     console.log(`Letter ${i} is ${logo[i].getTotalLength()}`);
// }